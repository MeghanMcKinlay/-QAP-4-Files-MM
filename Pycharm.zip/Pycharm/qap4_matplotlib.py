import matplotlib.pyplot as plt

# Prompt user for total sales input
sales = []
months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

for month in months:
    sales_amount = float(input(f"Enter total sales for {month}: "))
    sales.append(sales_amount)

# Plotting the graph
plt.plot(months, sales)
plt.title("Total Sales per Month")
plt.xlabel("Months")
plt.ylabel("Sales ($)")
plt.show()
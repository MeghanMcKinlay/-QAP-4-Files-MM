import datetime

# Function to validate province
def validate_province(province):
    valid_provinces = ["NL", "PE", "NS", "NB", "QC", "ON", "MB", "SK", "AB", "BC"]
    return province.upper() in valid_provinces

# Read values from defaults file
with open("OSICDef.dat", "r") as file:
    data = file.read().split('.')
    policy_number = int(data[0])
    basic_premium = float(data[1])
    discount_additional_cars = float(data[2])
    cost_extra_liability = float(data[3])
    cost_glass_coverage = float(data[4])
    cost_loaner_car_coverage = float(data[5])
    hst_rate = float(data[6])
    processing_fee = float(data[7])

# Prompt user for input
first_name = input("Enter customer's first name: ")
last_name = input("Enter customer's last name: ")
address = input("Enter customer's address: ")
city = input("Enter customer's city: ")
province = input("Enter customer's province: ")
while not validate_province(province):
    province = input("Enter a valid province: ")
postal_code = input("Enter customer's postal code: ")
phone_number = input("Enter customer's phone number: ")
num_cars = int(input("Enter the number of cars being insured: "))
extra_liability = input("Do you want extra liability coverage? (Y/N): ").upper()
glass_coverage = input("Do you want glass coverage? (Y/N): ").upper()
loaner_car = input("Do you want loaner car coverage? (Y/N): ").upper()
payment_method = input("Enter the payment method (Full/Monthly): ").capitalize()

# Calculate premium
total_premium = basic_premium + (num_cars - 1) * (basic_premium * discount_additional_cars)

# Calculate extra costs
extra_costs = 0.0
if extra_liability == 'Y':
    extra_costs += cost_extra_liability * num_cars
if glass_coverage == 'Y':
    extra_costs += cost_glass_coverage * num_cars
if loaner_car == 'Y':
    extra_costs += cost_loaner_car_coverage * num_cars

# Calculate total insurance premium
total_insurance_premium = total_premium + extra_costs

# Calculate HST
hst = total_insurance_premium * hst_rate

# Calculate total cost
total_cost = total_insurance_premium + hst

# Calculate monthly payment
if payment_method == 'Monthly':
    monthly_payment = (total_cost + processing_fee) / 8

# Generate receipt
current_date = datetime.datetime.now().strftime("%Y-%m-%d")
receipt = f"""
Receipt
----------------------------
Customer: {first_name.title()} {last_name.title()}
Address: {address}
City: {city.title()}
Province: {province.upper()}
Postal Code: {postal_code}
Phone Number: {phone_number}
Number of Cars Insured: {num_cars}
Extra Liability Coverage: {extra_liability}
Glass Coverage: {glass_coverage}
Loaner Car Coverage: {loaner_car}
Payment Method: {payment_method}
----------------------------
Premium: ${total_premium:.2f}
Extra Costs: ${extra_costs:.2f}
----------------------------
Total Insurance Premium: ${total_insurance_premium:.2f}
HST: ${hst:.2f}
Total Cost: ${total_cost:.2f}
----------------------------
Invoice Date: {current_date}
"""
print(receipt)

# Save policy information to file
policy_data = f"{policy_number}, {current_date}, {first_name}, {last_name}, {address}, {city}, {province}, {postal_code}, {phone_number}, {num_cars}, {extra_liability}, {glass_coverage}, {loaner_car}, {payment_method}, {total_insurance_premium:.2f}"
with open("Policies.dat", "a") as file:
    file.write(policy_data + "\n")

# Increase policy number by 1
policy_number += 1

# Update defaults file
with open("OSICDef.dat", "w") as file:
    file.write(f"{policy_number}.{basic_premium}.{discount_additional_cars}.{cost_extra_liability}.{cost_glass_coverage}.{cost_loaner_car_coverage}.{hst_rate}.{processing_fee}")

print("Policy information processed and saved.")
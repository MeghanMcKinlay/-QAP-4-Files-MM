# Description: Allows the user to enter the total amount of sales for each month from January to December
# Written By Meghan McKinlay
# Date Written is July 17 - 26, 2023

import matplotlib.pyplot as plt

# Prompt user for total sales input
sales = []
months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

for month in months:
    sales_amount = float(input(f"Enter total sales for {month}: "))
    sales.append(sales_amount)

# Plotting the graph
plt.plot(months, sales)
plt.title("Total Sales per Month")
plt.xlabel("Months")
plt.ylabel("Sales ($)")
plt.show()